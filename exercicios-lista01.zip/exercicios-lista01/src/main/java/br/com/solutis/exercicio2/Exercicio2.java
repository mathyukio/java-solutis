package br.com.solutis.exercicio2;

public class Exercicio2 {

    public Integer verificarMaiorNumero(Integer a, Integer b) {
        if (a > b) {
            System.out.println("O maior número é: " + a);
            return a;
        } else if (a < b) {
            System.out.println("O maior número é: " + b);
            return b;
        } else {
            System.out.println("Os numeros são iguais");
            return 0;
        }


    }
}
