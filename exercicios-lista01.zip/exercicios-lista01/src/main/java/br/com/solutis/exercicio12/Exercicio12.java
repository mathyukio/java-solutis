package br.com.solutis.exercicio12;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Exercicio12 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int totaldeKm = 0;
        int totaldeLitros = 0;

        List<Double> tanques = new ArrayList<>();
        int nTanques = 1;

        while (true) {
            System.out.println();

            System.out.println("Tanque número: " + nTanques);
            System.out.println("Digite os quilômetros dirigidos ou digite 0 para sair: ");
            int quilometros = sc.nextInt();

            if (quilometros == 0) {
                break;
            }

            System.out.println("Digite o consumo de litros do tanque: ");
            int litros = sc.nextInt();

            double consumo = (double) quilometros / litros;
            double arrendondar = Math.round(consumo * 100.0) / 100.0;
            tanques.add(arrendondar);
            System.out.println("Consumo do tanque foi de: " + arrendondar + "km/l");

            totaldeKm += quilometros;
            totaldeLitros += litros;
            nTanques++;
        }

        if (totaldeKm > 0 && totaldeLitros > 0) {
            double mediaGeral = (double) totaldeKm / totaldeLitros;
            double arrendondar2 = Math.round(mediaGeral * 100.0) / 100.0;

            for (int i = 0; i < tanques.size(); i++) {
                System.out.println("Tanque " + (i + 1) + ": " + tanques.get(i) + " km/l");
            }

            System.out.println("O consumo geral foi de:  " + arrendondar2 + " km/l");
            System.out.println("O total de quilômetros geral: " + totaldeKm + " km.");
            System.out.println("O total de litros geral: " + totaldeLitros + " litros.");
        }

        sc.close();
    }
}
