package br.com.solutis.exercicio9;

public class Exercicio9 {

    Double area;

    public void calcularRaio(Double raio) {

        area = Math.PI * (raio * raio);
        Long arrendondar = Math.round(area);

        System.out.println(arrendondar);
    }
}
