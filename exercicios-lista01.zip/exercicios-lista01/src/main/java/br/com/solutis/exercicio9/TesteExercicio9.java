package br.com.solutis.exercicio9;

import java.util.Scanner;

public class TesteExercicio9 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Exercicio9 exercicio9 = new Exercicio9();

        System.out.println("Digite o valor do raio: ");
        Double raio = sc.nextDouble();

        exercicio9.calcularRaio(raio);
        sc.close();
    }
}
