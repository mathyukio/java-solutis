package br.com.solutis.exercicio10;

import java.util.Scanner;

public class TesteExercicio10 {

    public static void main(String[] args) {

        Exercicio10 ex = new Exercicio10();
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite um texto: ");
        String texto = sc.nextLine();

        ex.validarString(texto);
        sc.close();
    }
}
