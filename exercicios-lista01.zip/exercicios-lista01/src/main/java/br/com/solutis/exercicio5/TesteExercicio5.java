package br.com.solutis.exercicio5;

import java.util.Scanner;

public class TesteExercicio5 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Exercicio5 ex = new Exercicio5();

        System.out.println("Digite um numero de 1 a 7: ");
        Integer num1 = sc.nextInt();

        ex.diaDaSemanaArray(num1);
        sc.close();
    }
}
