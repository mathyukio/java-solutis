package br.com.solutis.exercicio3;

import java.util.Scanner;

public class TesteExercicio3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Exercicio3 ex = new Exercicio3();


        System.out.println("Digite um numero: ");
        Integer num1 = sc.nextInt();

        for (int i = 2; i < num1; i++) {
            if (ex.verificarPrimos(i)) {
                System.out.println(i);
            }
        }
    }
}
