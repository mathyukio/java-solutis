package br.com.solutis.exercicio8;

import java.util.Scanner;

public class TesteExercicio8 {

    public static void main(String[] args) {
        Exercicio8 exercicio8 = new Exercicio8();
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite uma palavra: ");
        String palavra = sc.nextLine();

        System.out.println(exercicio8.verificarPalindromo(palavra));
        sc.close();
    }
}
