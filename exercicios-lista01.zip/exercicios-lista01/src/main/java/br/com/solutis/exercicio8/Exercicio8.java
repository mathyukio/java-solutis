package br.com.solutis.exercicio8;

public class Exercicio8 {

    public String verificarPalindromo(String palavra){

        String palavraMinuscula = palavra.toLowerCase();
        Integer tamanho = palavraMinuscula.length();

        for(int i = 0; i < tamanho / 2; i++){
            if (palavraMinuscula.charAt(i) != palavraMinuscula.charAt(tamanho - 1 - i)) {
                return "A palavra não é um palíndromo.";
            }
        }
        return "A palavra é um palindromo.";
    }
}
