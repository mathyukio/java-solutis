package br.com.solutis.exercicio2;

import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;

public class TesteExercicio2 {

    public static void main(String[] args) {

        Exercicio2 ex = new Exercicio2();
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o primeiro numero: ");
        Integer num1 = sc.nextInt();
        System.out.println("Digite o segundo numero: ");
        Integer num2 = sc.nextInt();

        ex.verificarMaiorNumero(num1, num2);
        sc.close();

    }


}
