package br.com.solutis.exercicio7;

public class TesteExercicio7 {

    public static void main(String[] args) {
        Exercicio7 exercicio7 = new Exercicio7();

        exercicio7.dividirMultiplos3();
    }
}
