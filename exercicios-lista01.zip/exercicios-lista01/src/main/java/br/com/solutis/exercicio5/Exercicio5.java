package br.com.solutis.exercicio5;

public class Exercicio5 {

    String[] semanaArray;

    public void diaDaSemanaArray(Integer numero){
        semanaArray = new String[7];

        for(int i = 1; i <= 7; i++){

            switch (numero){
                case 1:
                    semanaArray[i - 1] = "Segunda-Feira";
                    break;
                case 2:
                    semanaArray[i - 1] = "Terça-Feira";
                    break;
                case 3:
                    semanaArray[i - 1] = "Quarta-Feira";
                    break;
                case 4:
                    semanaArray[i - 1] = "Quinta-Feira";
                    break;
                case 5:
                    semanaArray[i - 1] = "Sexta-Feira";
                    break;
                case 6:
                    semanaArray[i - 1] = "Sabado";
                    break;
                case 7:
                    semanaArray[i - 1] = "Domingo";
                    break;
            }
        }

        if (numero > 7 || numero < 1) {
            System.out.println("O numero deve ser maior ou igual a 7");
        } else {
            System.out.println("O dia da semana é: " + semanaArray[numero - 1]);
        }
    }
}
