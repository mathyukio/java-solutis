package br.com.solutis.exercicio3;

import java.util.Scanner;

public class Exercicio3 {

    public Boolean verificarPrimos(Integer num1) {

        for (int i = 2; i < num1; i++) {
            if (num1 % i == 0) {
                return false;
            }
        }
        return true;
    }

}
