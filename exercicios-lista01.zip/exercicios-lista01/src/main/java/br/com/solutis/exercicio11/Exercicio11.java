package br.com.solutis.exercicio11;

public class Exercicio11 {

    public void compararPalavras(String palavra1, String palavra2) {

        if (palavra1.compareTo(palavra2) < 0) {
            System.out.println("Ordem alfabética: " + palavra1 + ", " + palavra2);
        } else if (palavra1.compareTo(palavra2) > 0) {
            System.out.println("Ordem alfabética: " + palavra2 + ", " + palavra1);
        } else {
            System.out.println("As palavras são iguais: " + palavra1 + ", " + palavra2);
        }

        if (palavra1.length() > palavra2.length()) {
            System.out.println("A primeira palavra tem mais caracteres do que a segunda palavra.");
        } else if (palavra2.length() > palavra1.length()) {
            System.out.println("A segunda palavra tem mais caracteres do que a primeira palavra.");
        } else {
            System.out.println("As palavras tem a mesma quantidade de caracteres.");
        }

    }
}
