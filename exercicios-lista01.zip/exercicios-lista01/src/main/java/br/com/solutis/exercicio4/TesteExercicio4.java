package br.com.solutis.exercicio4;

import java.util.Scanner;

public class TesteExercicio4 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Exercicio4 ex = new Exercicio4();

        System.out.println("Digite um valor em milhas: ");
        Integer milhas = sc.nextInt();

        ex.conversorDeKm(milhas);
        sc.close();

    }
}
