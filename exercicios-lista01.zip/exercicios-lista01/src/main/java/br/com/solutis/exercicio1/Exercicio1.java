package br.com.solutis.exercicio1;

public class Exercicio1 {

    public static void main(String[] args) {

        int i = 5;
        int j = i;
        j = 10;

        System.out.println("i + j = " + i + j);
    }
}
