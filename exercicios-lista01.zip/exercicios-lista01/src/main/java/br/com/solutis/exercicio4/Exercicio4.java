package br.com.solutis.exercicio4;

public class Exercicio4 {

    public void conversorDeKm(Integer milhas) {

        milhas = milhas * 1609;
        System.out.println("Você andou: " + milhas + " KMs");
    }
}
