package br.com.solutis.exercicio11;

import java.util.Scanner;

public class TesteExercicio11 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Exercicio11 ex = new Exercicio11();

        System.out.println("Digite a primeira palavra: ");
        String palavra1 = sc.nextLine();
        System.out.println("Digite a segunda palavra: ");
        String palavra2 = sc.nextLine();

        ex.compararPalavras(palavra1, palavra2);
        sc.close();
    }
}
