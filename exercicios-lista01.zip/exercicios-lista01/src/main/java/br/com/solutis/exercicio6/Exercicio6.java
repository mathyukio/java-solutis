package br.com.solutis.exercicio6;

public class Exercicio6 {

    public static void main(String[] args) {

        Integer produto;
        float valor;

        for (int i = 15; i <= 30; i++) {
            if (i % 2 != 0) {
                for (int j = 15; j <= 30; j++) {
                    if (j % 2 != 0){
                        produto = i * j;
                        valor = i * j;
                        System.out.println(produto);
                        System.out.println(valor);
                    }
                }
            }
        }

        // Fiquei em dúvida em relação ao enunciado do exercicio, então realizei de duas formas diferentes

        /*
        int produtoInt = 1;
        float produtoFloat = 1;

        for (int i = 15; i <= 30; i++) {
            if (i % 2 != 0) {
                produtoInt *= i;
                produtoFloat *= i;
            }
        }

        System.out.println("Produto (int): " + produtoInt);
        System.out.println("Produto (float): " + produtoFloat);

        Nesse caso os valores de int vão estourar devido a quantidade de caracteres
         */
    }
}
