package br.com.solutis.exercicio10;

public class Exercicio10 {

    public void validarString(String texto) {

        texto = texto.toLowerCase();

        Integer quantidadeBranco = 0;
        Integer quantidadeVogal = 0;
        Integer quantidadeConsoante = 0;

        for (int i = 0; i < texto.length(); i++) {
            if (texto.charAt(i) == ' ') {
                quantidadeBranco++;
            } else if (texto.charAt(i) == 'a' || texto.charAt(i) == 'e' || texto.charAt(i) == 'i'
                    || texto.charAt(i) == 'o' || texto.charAt(i) == 'u') {
                quantidadeVogal++;
            } else {
                quantidadeConsoante++;
            }
        }
        System.out.println("Quantidade de brancos: " + quantidadeBranco);
        System.out.println("Quantidade de vogais: " + quantidadeVogal);
        System.out.println("Quantidade de consoantes: " + quantidadeConsoante);
    }
}
