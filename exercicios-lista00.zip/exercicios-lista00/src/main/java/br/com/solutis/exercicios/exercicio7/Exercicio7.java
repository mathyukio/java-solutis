package br.com.solutis.exercicios.exercicio7;

import java.util.Scanner;

public class Exercicio7 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o primeiro numero: ");
        Integer a = sc.nextInt();
        System.out.println("Digite o segundo numero: ");
        Integer b = sc.nextInt();

        sc.close();

        a = b;
        b = a;

        System.out.println("Valor de a: " + a);
        System.out.println("Valor de b: " + b);
    }
}
