package br.com.solutis.exercicios.exercicio13;

import br.com.solutis.exercicios.exercicio12.Exercicio12;

public class TesteExercicio13 {

    public static void main(String[] args) {
        Exercicio13 exercicio13 = new Exercicio13();

        exercicio13.somaDe7();
    }
}
