package br.com.solutis.exercicios.exercicio10;

public class Exercicio10 {
    public static void main(String[] args) {

        Integer a = 6;
        Integer b = 4;
        Integer c = a / b;

        System.out.println(c);

        /*
         A variavel c realiza a operacao de divisao de dois numeros inteiros a e b
         porem o resultado desse valor é de 1,5, mas pela variavel c ser do tipo Integer
         e nao do valor Double, o Java por de trás da aplicação aplica um auto casting,
         arredondando esse numero de 1,5 -> 1.
        */
    }
}
