package br.com.solutis.exercicios.exercicio13;

public class Exercicio13 {

    public void somaDe7(){
        for (int i = 1; i <= 6; i++) {
            for (int j = 1; j <= 6; j++) {

                if (i + j == 7) {
                    System.out.println("A soma dos dados é 7 " + " Valor do primeiro dado é: "
                            + i + " Valor do segundo dado: " + j);
                }
            }
        }
    }
    }
