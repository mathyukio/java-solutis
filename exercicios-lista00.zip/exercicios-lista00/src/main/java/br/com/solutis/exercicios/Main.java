package br.com.solutis.exercicios;

public class Main {

    public static void main(String[] args) {

    }
}
