package br.com.solutis.exercicios.exercicio11;

public class Exercicio11 {

    public void validarNumero(Integer num) {

        switch (num) {
            case 1:
                System.out.println("Parafuso");
                break;
            case 2:
                System.out.println("Porca");
                break;
            case 3:
                System.out.println("Prego");
                break;
            default:
                System.out.println("Diversos");
                break;
        }
    }
}
