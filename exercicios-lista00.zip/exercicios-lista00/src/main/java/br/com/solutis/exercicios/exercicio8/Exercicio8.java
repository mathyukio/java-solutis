package br.com.solutis.exercicios.exercicio8;

public class Exercicio8 {

    public void verificarParOuImpar(Integer numero) {

        if (numero % 2 == 0) {
            System.out.println("O número digitado é par");
        } else {
            System.out.println("O número digitado é impar");
        }
    }

}
