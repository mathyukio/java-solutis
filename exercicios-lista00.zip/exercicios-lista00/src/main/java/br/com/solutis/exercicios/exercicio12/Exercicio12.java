package br.com.solutis.exercicios.exercicio12;

public class Exercicio12 {

    public void dividirMultiplos3() {

        for (int i = 1; i <= 100 ; i++) {
            if (i % 3 == 0) {

                Integer resultadoInt = i / 2;
                System.out.println("O resultado por inteiro é: " + resultadoInt);

                Double resultadoDouble = i / 2.0;
                System.out.println("O resultado por flutuante é: " + resultadoDouble);
            }
        }
    }

}
