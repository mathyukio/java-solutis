package br.com.solutis.exercicios.exercicio9;

public class Exercicio9 {

    public void calcularQuadrados() {
        for (int i = 0; i <= 10; i++) {
            System.out.println(i * i);
        }
    }
}
