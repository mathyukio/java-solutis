package br.com.solutis.exercicios.exercicio12;

public class TesteExercicio12 {

    public static void main(String[] args) {
        Exercicio12 exercicio12 = new Exercicio12();

        exercicio12.dividirMultiplos3();
    }
}
