package br.com.solutis.exercicios.exercicio11;

import java.util.Scanner;

public class TesteExercicio11 {

    public static void main(String[] args) {
        Exercicio11 exercicio11 = new Exercicio11();

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite um numero: ");
        Integer num = sc.nextInt();
        exercicio11.validarNumero(num);
        sc.close();
    }
}
