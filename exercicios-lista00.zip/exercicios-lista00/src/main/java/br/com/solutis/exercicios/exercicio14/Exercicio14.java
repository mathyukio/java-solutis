package br.com.solutis.exercicios.exercicio14;

import java.util.Scanner;

public class Exercicio14 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Integer i = 1;
        Double soma = 0.0;
        Double numero = 0.0;
        Double media = 0.0;

        while (i <= 50){
            System.out.print("Digite o " + i + " número: ");
            numero = sc.nextDouble();
            soma += numero;
            i++;
        }

        media = soma / 50;

        System.out.println("A soma das médias dos 50 números é: " + soma);
        sc.close();

    }
}
