package br.com.solutis.exercicios.exercicio8;

import java.util.Scanner;

public class TesteExercicio8 {
    public static void main(String[] args) {

        Exercicio8 ex = new Exercicio8();

        ex.verificarParOuImpar(8);
        ex.verificarParOuImpar(9);
        ex.verificarParOuImpar(10);
        ex.verificarParOuImpar(71);
    }
}
