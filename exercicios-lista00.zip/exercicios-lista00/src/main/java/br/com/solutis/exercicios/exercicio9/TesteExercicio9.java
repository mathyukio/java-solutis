package br.com.solutis.exercicios.exercicio9;

public class TesteExercicio9 {

    public static void main(String[] args) {

        Exercicio9 exercicio9 = new Exercicio9();

        exercicio9.calcularQuadrados();
    }
}
